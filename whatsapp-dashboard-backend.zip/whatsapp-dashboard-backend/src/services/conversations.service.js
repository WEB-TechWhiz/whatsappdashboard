const pool = require("../config/db");
const { NotFoundError } = require("../utils/errors");

// Shapes a DB row into the frontend's `Conversation` type
function toConversationDTO(row) {
  return {
    id: row.id,
    name: row.name,
    preview: row.last_message_preview || "",
    time: row.last_message_at || row.updated_at,
    unread: Number(row.unread_count) || 0,
    online: row.online,
  };
}

function toMessageDTO(row) {
  return {
    id: row.id,
    text: row.text,
    isAgent: row.is_agent,
    time: row.created_at,
    read: row.read,
    mediaUrl: row.media_url || undefined,
  };
}

async function listConversations(workspaceId, search) {
  const params = [workspaceId];
  let searchClause = "";

  if (search) {
    params.push(`%${search}%`);
    searchClause = `AND c.name ILIKE $${params.length}`;
  }

  // Correlated subqueries for last message + unread count — fine at dashboard
  // scale (dozens-hundreds of contacts per workspace); revisit with a
  // materialized view if a single workspace grows into the thousands.
  const { rows } = await pool.query(
    `SELECT
       c.id, c.name, c.online, c.updated_at,
       (SELECT text FROM messages m WHERE m.contact_id = c.id ORDER BY created_at DESC LIMIT 1) AS last_message_preview,
       (SELECT created_at FROM messages m WHERE m.contact_id = c.id ORDER BY created_at DESC LIMIT 1) AS last_message_at,
       (SELECT COUNT(*) FROM messages m WHERE m.contact_id = c.id AND m.is_agent = false AND m.read = false) AS unread_count
     FROM contacts c
     WHERE c.workspace_id = $1 ${searchClause}
     ORDER BY last_message_at DESC NULLS LAST`,
    params
  );

  return rows.map(toConversationDTO);
}

async function getMessages(workspaceId, contactId, limit = 50, offset = 0) {
  const contact = await pool.query(
    `SELECT id FROM contacts WHERE id = $1 AND workspace_id = $2`,
    [contactId, workspaceId]
  );
  if (contact.rows.length === 0) throw new NotFoundError("Conversation");

  const { rows } = await pool.query(
    `SELECT * FROM messages WHERE contact_id = $1
     ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
    [contactId, limit, offset]
  );

  return rows.reverse().map(toMessageDTO); // reverse: chronological order for chat rendering
}

async function sendMessage(workspaceId, contactId, { text, mediaUrl }) {
  const contact = await pool.query(
    `SELECT id FROM contacts WHERE id = $1 AND workspace_id = $2`,
    [contactId, workspaceId]
  );
  if (contact.rows.length === 0) throw new NotFoundError("Conversation");

  const { rows } = await pool.query(
    `INSERT INTO messages (workspace_id, contact_id, text, media_url, is_agent, read)
     VALUES ($1, $2, $3, $4, true, true)
     RETURNING *`,
    [workspaceId, contactId, text, mediaUrl || null]
  );

  await pool.query(`UPDATE contacts SET updated_at = now() WHERE id = $1`, [contactId]);

  // NOTE: this only writes to the dashboard's own DB. Actually delivering the
  // message over WhatsApp means calling your existing WhatsApp automation
  // backend's send function (the one your webhook/BullMQ worker already uses)
  // — wire that call in here once this service is deployed alongside it.

  return toMessageDTO(rows[0]);
}

async function markRead(workspaceId, contactId) {
  await pool.query(
    `UPDATE messages SET read = true
     WHERE contact_id = $1 AND workspace_id = $2 AND is_agent = false AND read = false`,
    [contactId, workspaceId]
  );
}

module.exports = { listConversations, getMessages, sendMessage, markRead };
