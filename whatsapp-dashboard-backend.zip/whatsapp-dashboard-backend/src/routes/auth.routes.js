const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit");
const pool = require("../config/db");
const asyncHandler = require("../utils/asyncHandler");
const validate = require("../middleware/validate");
const requireAuth = require("../middleware/auth");
const schemas = require("../validators/schemas");
const { UnauthorizedError } = require("../utils/errors");

const router = express.Router();

// Brute-force protection on login specifically — 10 attempts per 15 min per IP.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "RATE_LIMITED", message: "Too many login attempts. Try again later." },
});

router.post(
  "/auth/login",
  loginLimiter,
  validate(schemas.login),
  asyncHandler(async (req, res) => {
    const { email, password } = req.body;

    const { rows } = await pool.query(`SELECT * FROM workspaces WHERE email = $1`, [email]);
    const workspace = rows[0];

    // Constant-shape response whether the email exists or not — don't leak
    // which part of the credential pair was wrong.
    if (!workspace) throw new UnauthorizedError("Invalid email or password");

    const valid = await bcrypt.compare(password, workspace.password_hash);
    if (!valid) throw new UnauthorizedError("Invalid email or password");

    const token = jwt.sign(
      { workspaceId: workspace.id },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
    );

    res.json({
      token,
      workspace: { id: workspace.id, name: workspace.name, email: workspace.email },
    });
  })
);

router.get(
  "/workspace/profile",
  requireAuth,
  asyncHandler(async (req, res) => {
    const { rows } = await pool.query(
      `SELECT id, name, email, whatsapp_phone, auto_reply, notify_new_leads, flag_leaks, created_at
       FROM workspaces WHERE id = $1`,
      [req.workspaceId]
    );
    res.json(rows[0]);
  })
);

module.exports = router;
